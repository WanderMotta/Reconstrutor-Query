/**
 * Editor de Consultas SQL
 * Script para gerenciar a interface gráfica e interações com o backend
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elementos da interface
    const sqlQuery = document.getElementById('sqlQuery');
    const sqlQueryError = document.getElementById('sqlQueryError');
    const sqlFileUpload = document.getElementById('sqlFileUpload');
    const btnLoadExample = document.getElementById('btnLoadExample');
    const btnAnalyzeQuery = document.getElementById('btnAnalyzeQuery');
    const btnReconstructQuery = document.getElementById('btnReconstructQuery');
    const btnCopyQuery = document.getElementById('btnCopyQuery');
    const btnDownloadQuery = document.getElementById('btnDownloadQuery');
    const btnStartOver = document.getElementById('btnStartOver');
    const conditionsPanel = document.getElementById('conditionsPanel');
    const conditionsContainer = document.getElementById('conditionsContainer');
    const noConditionsMessage = document.getElementById('noConditionsMessage');
    const resultsPanel = document.getElementById('resultsPanel');
    const reconstructedQuery = document.getElementById('reconstructedQuery');
    const loadingOverlay = document.getElementById('loadingOverlay');

    // Variáveis para armazenar dados da consulta
    let originalQuery = '';
    let parsedConditions = [];

    // Exemplo de consulta SQL
    const EXAMPLE_QUERY = `SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.email,
    COUNT(o.order_id) AS total_orders,
    SUM(o.total_amount) AS total_spent
FROM 
    customers c
JOIN 
    orders o ON c.customer_id = o.customer_id
WHERE 
    c.status = 'active' 
    AND c.created_date > '2022-01-01'
    AND o.total_amount > 100.00
    AND o.order_status IN ('completed', 'shipped')
    AND c.last_login BETWEEN '2022-06-01' AND '2022-12-31'
GROUP BY 
    c.customer_id, c.first_name, c.last_name, c.email
HAVING 
    COUNT(o.order_id) >= 3
ORDER BY 
    total_spent DESC
LIMIT 100;`;

    // Inicialização de listeners
    btnLoadExample.addEventListener('click', loadExampleQuery);
    sqlFileUpload.addEventListener('change', handleFileUpload);
    btnAnalyzeQuery.addEventListener('click', analyzeQuery);
    btnReconstructQuery.addEventListener('click', reconstructQuery);
    btnCopyQuery.addEventListener('click', copyQuery);
    btnDownloadQuery.addEventListener('click', downloadQuery);
    btnStartOver.addEventListener('click', startOver);

    /**
     * Carrega uma consulta SQL de exemplo no editor
     */
    function loadExampleQuery() {
        sqlQuery.value = EXAMPLE_QUERY;
        hideError();
    }

    /**
     * Manipula o upload de um arquivo SQL
     */
    function handleFileUpload(event) {
        showLoading();
        const file = event.target.files[0];
        
        if (file && file.name.endsWith('.sql')) {
            const formData = new FormData();
            formData.append('sqlFile', file);
            
            fetch('/upload_sql', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showError(data.error);
                } else {
                    sqlQuery.value = data.query;
                    hideError();
                }
            })
            .catch(error => {
                showError('Erro ao processar o arquivo: ' + error.message);
            })
            .finally(() => {
                hideLoading();
                // Limpa o input file para permitir selecionar o mesmo arquivo novamente
                sqlFileUpload.value = '';
            });
        } else {
            hideLoading();
            showError('Por favor, selecione um arquivo .sql válido');
            sqlFileUpload.value = '';
        }
    }

    /**
     * Analisa a consulta SQL e extrai as condições WHERE
     */
    function analyzeQuery() {
        const query = sqlQuery.value.trim();
        if (!query) {
            showError('Por favor, insira uma consulta SQL');
            return;
        }

        showLoading();
        
        const formData = new FormData();
        formData.append('query', query);
        
        fetch('/parse_query', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showError(data.error);
                hideConditionsPanel();
            } else if (data.status === 'no_where') {
                // Exibe uma mensagem mais amigável quando não há cláusula WHERE com HTML incorporado
                sqlQueryError.innerHTML = `
                    <div>${data.message}</div>
                    <div class="mt-2">
                        <p>Este editor é especializado em modificar condições WHERE. Exemplo de consulta válida:</p>
                        <pre class="bg-dark text-light p-2">SELECT * FROM tabela WHERE coluna = valor</pre>
                        <p>Adicione uma cláusula WHERE à sua consulta para poder usar o editor.</p>
                    </div>
                `;
                sqlQueryError.classList.remove('d-none');
                
                hideConditionsPanel();
            } else {
                hideError();
                originalQuery = data.query;
                parsedConditions = data.conditions;
                displayConditions(parsedConditions);
            }
        })
        .catch(error => {
            showError('Erro ao analisar a consulta: ' + error.message);
            hideConditionsPanel();
        })
        .finally(() => {
            hideLoading();
        });
    }

    /**
     * Exibe as condições extraídas da consulta SQL
     */
    function displayConditions(conditions) {
        conditionsContainer.innerHTML = '';
        
        if (!conditions || conditions.length === 0) {
            noConditionsMessage.classList.remove('d-none');
            conditionsPanel.classList.remove('d-none');
            return;
        }
        
        noConditionsMessage.classList.add('d-none');
        
        conditions.forEach(condition => {
            const conditionElement = createConditionElement(condition);
            conditionsContainer.appendChild(conditionElement);
        });
        
        conditionsPanel.classList.remove('d-none');
        resultsPanel.classList.add('d-none');
    }

    /**
     * Cria um elemento HTML para uma condição WHERE
     */
    function createConditionElement(condition) {
        const conditionCard = document.createElement('div');
        conditionCard.className = 'card mb-3';
        conditionCard.dataset.conditionId = condition.id;
        
        const cardBody = document.createElement('div');
        cardBody.className = 'card-body';
        
        // Cria o campo para o nome do campo
        const fieldRow = document.createElement('div');
        fieldRow.className = 'row mb-3';
        
        const fieldLabel = document.createElement('label');
        fieldLabel.className = 'col-sm-3 col-form-label';
        fieldLabel.textContent = 'Campo:';
        
        const fieldValueCol = document.createElement('div');
        fieldValueCol.className = 'col-sm-9';
        
        const fieldValue = document.createElement('input');
        fieldValue.type = 'text';
        fieldValue.className = 'form-control';
        fieldValue.value = condition.field;
        fieldValue.readOnly = true; // O campo não é editável
        
        fieldValueCol.appendChild(fieldValue);
        fieldRow.appendChild(fieldLabel);
        fieldRow.appendChild(fieldValueCol);
        
        // Cria o campo para o operador
        const operatorRow = document.createElement('div');
        operatorRow.className = 'row mb-3';
        
        const operatorLabel = document.createElement('label');
        operatorLabel.className = 'col-sm-3 col-form-label';
        operatorLabel.textContent = 'Operador:';
        
        const operatorValueCol = document.createElement('div');
        operatorValueCol.className = 'col-sm-9';
        
        const operatorSelect = document.createElement('select');
        operatorSelect.className = 'form-select condition-operator';
        
        // Adiciona os operadores disponíveis
        const operators = [
            { value: '=', text: 'igual (=)' },
            { value: '!=', text: 'diferente (!=)' },
            { value: '<>', text: 'diferente (<>)' },
            { value: '>', text: 'maior (>)' },
            { value: '<', text: 'menor (<)' },
            { value: '>=', text: 'maior ou igual (>=)' },
            { value: '<=', text: 'menor ou igual (<=)' },
            { value: 'LIKE', text: 'contém (LIKE)' },
            { value: 'NOT LIKE', text: 'não contém (NOT LIKE)' },
            { value: 'IN', text: 'em lista (IN)' },
            { value: 'NOT IN', text: 'não em lista (NOT IN)' },
            { value: 'BETWEEN', text: 'entre (BETWEEN)' },
            { value: 'NOT BETWEEN', text: 'não entre (NOT BETWEEN)' },
            { value: 'IS NULL', text: 'é nulo (IS NULL)' },
            { value: 'IS NOT NULL', text: 'não é nulo (IS NOT NULL)' }
        ];
        
        operators.forEach(op => {
            const option = document.createElement('option');
            option.value = op.value;
            option.textContent = op.text;
            
            // Seleciona o operador atual
            if (op.value.toUpperCase() === condition.operator.toUpperCase()) {
                option.selected = true;
            }
            
            operatorSelect.appendChild(option);
        });
        
        // Evento de mudança do operador para atualizar os campos de valor
        operatorSelect.addEventListener('change', function() {
            updateValueField(conditionCard, this.value, condition.type);
        });
        
        operatorValueCol.appendChild(operatorSelect);
        operatorRow.appendChild(operatorLabel);
        operatorRow.appendChild(operatorValueCol);
        
        // Cria o campo para o valor
        const valueRow = document.createElement('div');
        valueRow.className = 'row mb-2 condition-value-container';
        
        cardBody.appendChild(fieldRow);
        cardBody.appendChild(operatorRow);
        cardBody.appendChild(valueRow);
        
        conditionCard.appendChild(cardBody);
        
        // Inicializa o campo de valor
        updateValueField(conditionCard, condition.operator, condition.type, condition.value);
        
        return conditionCard;
    }

    /**
     * Atualiza o campo de valor baseado no operador selecionado
     */
    function updateValueField(conditionCard, operator, dataType, currentValue = null) {
        const valueContainer = conditionCard.querySelector('.condition-value-container');
        valueContainer.innerHTML = '';
        
        // Cria o label
        const valueLabel = document.createElement('label');
        valueLabel.className = 'col-sm-3 col-form-label';
        valueLabel.textContent = 'Valor:';
        
        const valueCol = document.createElement('div');
        valueCol.className = 'col-sm-9';
        
        // Verifica se o operador é IS NULL ou IS NOT NULL
        if (operator.toUpperCase() === 'IS NULL' || operator.toUpperCase() === 'IS NOT NULL') {
            const noValueText = document.createElement('p');
            noValueText.className = 'form-control-plaintext';
            noValueText.textContent = 'Não requer valor';
            
            valueCol.appendChild(noValueText);
        } 
        // Verifica se o operador é BETWEEN ou NOT BETWEEN
        else if (operator.toUpperCase() === 'BETWEEN' || operator.toUpperCase() === 'NOT BETWEEN') {
            const betweenContainer = document.createElement('div');
            betweenContainer.className = 'input-group';
            
            const valueStart = createInputByType(dataType, currentValue ? currentValue[0] : '');
            valueStart.className += ' condition-value-start';
            
            const andText = document.createElement('span');
            andText.className = 'input-group-text';
            andText.textContent = 'E';
            
            const valueEnd = createInputByType(dataType, currentValue ? currentValue[1] : '');
            valueEnd.className += ' condition-value-end';
            
            betweenContainer.appendChild(valueStart);
            betweenContainer.appendChild(andText);
            betweenContainer.appendChild(valueEnd);
            
            valueCol.appendChild(betweenContainer);
        } 
        // Verifica se o operador é IN ou NOT IN
        else if (operator.toUpperCase() === 'IN' || operator.toUpperCase() === 'NOT IN') {
            const inValues = document.createElement('textarea');
            inValues.className = 'form-control condition-value';
            inValues.rows = 3;
            inValues.placeholder = 'Insira valores separados por vírgula';
            
            if (currentValue && Array.isArray(currentValue)) {
                inValues.value = currentValue.join(', ');
            }
            
            valueCol.appendChild(inValues);
            
            const helpText = document.createElement('div');
            helpText.className = 'form-text';
            helpText.textContent = 'Insira os valores separados por vírgula';
            valueCol.appendChild(helpText);
        } 
        // Para todos os outros operadores
        else {
            const valueInput = createInputByType(dataType, currentValue || '');
            valueInput.className += ' condition-value';
            valueCol.appendChild(valueInput);
        }
        
        valueContainer.appendChild(valueLabel);
        valueContainer.appendChild(valueCol);
    }

    /**
     * Cria um input baseado no tipo de dados
     */
    function createInputByType(dataType, defaultValue) {
        let input;
        
        switch (dataType) {
            case 'number':
                input = document.createElement('input');
                input.type = 'number';
                input.step = 'any'; // Permite números decimais
                input.className = 'form-control';
                input.value = defaultValue;
                break;
                
            case 'date':
                input = document.createElement('input');
                input.type = 'date';
                input.className = 'form-control';
                
                // Converte a data para o formato YYYY-MM-DD aceito pelo input
                if (defaultValue) {
                    try {
                        // Tenta várias formatações comuns
                        let dateValue = defaultValue;
                        
                        // Verifica se é no formato DD/MM/YYYY
                        if (/^\d{2}\/\d{2}\/\d{4}/.test(defaultValue)) {
                            const parts = defaultValue.split('/');
                            dateValue = `${parts[2]}-${parts[1]}-${parts[0]}`;
                        }
                        
                        // Remove timestamp se houver
                        dateValue = dateValue.split(' ')[0];
                        
                        input.value = dateValue;
                    } catch (e) {
                        console.error('Erro ao converter data:', e);
                    }
                }
                break;
                
            default: // texto
                input = document.createElement('input');
                input.type = 'text';
                input.className = 'form-control';
                input.value = defaultValue;
                break;
        }
        
        return input;
    }

    /**
     * Reconstrói a consulta SQL com as condições modificadas
     */
    function reconstructQuery() {
        showLoading();
        
        // Coleta as condições modificadas
        const modifiedConditions = [];
        
        const conditionCards = conditionsContainer.querySelectorAll('.card');
        conditionCards.forEach(card => {
            const conditionId = parseInt(card.dataset.conditionId, 10);
            const field = card.querySelector('input[type="text"]').value;
            const operator = card.querySelector('.condition-operator').value;
            
            let value = null;
            
            // Obtém o valor dependendo do operador
            if (operator !== 'IS NULL' && operator !== 'IS NOT NULL') {
                if (operator === 'BETWEEN' || operator === 'NOT BETWEEN') {
                    const valueStart = card.querySelector('.condition-value-start').value;
                    const valueEnd = card.querySelector('.condition-value-end').value;
                    value = [valueStart, valueEnd];
                } else if (operator === 'IN' || operator === 'NOT IN') {
                    const inValues = card.querySelector('.condition-value').value;
                    value = inValues.split(',').map(v => v.trim());
                } else {
                    value = card.querySelector('.condition-value').value;
                }
            }
            
            // Encontra a condição original para manter o tipo de dado
            const originalCondition = parsedConditions.find(c => c.id === conditionId);
            const dataType = originalCondition ? originalCondition.type : 'text';
            
            modifiedConditions.push({
                id: conditionId,
                field: field,
                operator: operator,
                value: value,
                type: dataType
            });
        });
        
        // Envia as condições modificadas para o servidor
        fetch('/reconstruct_query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                original_query: originalQuery,
                modified_conditions: modifiedConditions
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showError(data.error);
            } else {
                hideError();
                reconstructedQuery.value = data.reconstructed_query;
                resultsPanel.classList.remove('d-none');
                // Rola para o painel de resultados
                resultsPanel.scrollIntoView({ behavior: 'smooth' });
            }
        })
        .catch(error => {
            showError('Erro ao reconstruir a consulta: ' + error.message);
        })
        .finally(() => {
            hideLoading();
        });
    }

    /**
     * Copia a consulta reconstruída para a área de transferência
     */
    function copyQuery() {
        const query = reconstructedQuery.value;
        
        if (!query) {
            return;
        }
        
        // Copia para a área de transferência
        navigator.clipboard.writeText(query)
            .then(() => {
                // Feedback visual
                const originalText = btnCopyQuery.innerHTML;
                btnCopyQuery.innerHTML = '<i class="fas fa-check me-1"></i> Copiado!';
                
                setTimeout(() => {
                    btnCopyQuery.innerHTML = originalText;
                }, 2000);
            })
            .catch(err => {
                showError('Falha ao copiar: ' + err.message);
            });
    }

    /**
     * Faz o download da consulta reconstruída como arquivo .sql
     */
    function downloadQuery() {
        const query = reconstructedQuery.value;
        
        if (!query) {
            return;
        }
        
        showLoading();
        
        fetch('/download_sql', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: query
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao gerar o arquivo');
            }
            return response.blob();
        })
        .then(blob => {
            // Cria um link de download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'consulta_modificada.sql';
            
            // Adiciona à página e clica
            document.body.appendChild(a);
            a.click();
            
            // Limpa
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        })
        .catch(error => {
            showError('Erro ao fazer download: ' + error.message);
        })
        .finally(() => {
            hideLoading();
        });
    }

    /**
     * Reinicia o processo com uma nova consulta
     */
    function startOver() {
        sqlQuery.value = '';
        hideError();
        hideConditionsPanel();
        resultsPanel.classList.add('d-none');
        // Rola para o topo
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    /**
     * Mostra uma mensagem de erro
     */
    function showError(message) {
        sqlQueryError.innerHTML = ''; // Limpa o conteúdo anterior
        sqlQueryError.textContent = message; // Define o texto da mensagem de erro
        sqlQueryError.classList.remove('d-none');
    }

    /**
     * Esconde a mensagem de erro
     */
    function hideError() {
        sqlQueryError.classList.add('d-none');
    }

    /**
     * Esconde o painel de condições
     */
    function hideConditionsPanel() {
        conditionsPanel.classList.add('d-none');
    }

    /**
     * Mostra o overlay de carregamento
     */
    function showLoading() {
        loadingOverlay.classList.remove('d-none');
    }

    /**
     * Esconde o overlay de carregamento
     */
    function hideLoading() {
        loadingOverlay.classList.add('d-none');
    }
});

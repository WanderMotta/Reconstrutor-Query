SELECT id, nome FROM clientes WHERE status = 'ativo'
